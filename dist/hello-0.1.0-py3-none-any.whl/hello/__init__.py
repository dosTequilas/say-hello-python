from .scripts.say_hello import main

